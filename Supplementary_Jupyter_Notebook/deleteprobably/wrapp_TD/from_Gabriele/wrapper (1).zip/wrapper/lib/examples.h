#ifndef EXAMPLES_H
#define EXAMPLES_H

void hello(const char *name);

#endif