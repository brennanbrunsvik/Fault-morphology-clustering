import pyexamples
import numpy as np

pywrapper.DispInHalfSpace(np.zeros(3),0.1,0.2,0.3,np.array([0.01,0.01,0.01]),np.array([0.01,0.01,0.02]),np.array([0.01,0.02,0.01]),0.001,0.002,0.,.3)

