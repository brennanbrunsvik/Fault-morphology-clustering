#include <stdio.h>

#include "examples.h"

void hello(const char *name) {
    printf("hello %s\n", name);
}