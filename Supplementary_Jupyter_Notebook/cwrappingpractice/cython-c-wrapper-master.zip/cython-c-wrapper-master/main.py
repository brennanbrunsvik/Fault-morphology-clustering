import pyexamples

pyexamples.py_hello(b"world")
